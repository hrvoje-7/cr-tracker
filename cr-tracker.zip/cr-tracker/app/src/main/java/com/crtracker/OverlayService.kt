package com.crtracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

// Cijene karata (uredi po potrebi, igra se mijenja)
val CARDS: Map<Int, List<String>> = mapOf(
    1 to listOf("Skeletons", "Ice Spirit", "Fire Spirit", "Electro Spirit", "Heal Spirit"),
    2 to listOf("Goblins", "Spear Gob", "Bats", "Zap", "Snowball", "Ice Golem", "Barb Barrel",
        "Wall Breakers", "Rage", "The Log", "Bomber", "Berserker", "Goblin Curse"),
    3 to listOf("Knight", "Archers", "Minions", "Arrows", "Cannon", "Goblin Gang", "Skel Army",
        "Guards", "Dart Goblin", "Bandit", "Royal Ghost", "Fisherman", "Miner", "Princess",
        "Ice Wizard", "Mega Minion", "Firecracker", "Skel Barrel", "Tombstone", "Royal Delivery",
        "Tornado", "Earthquake", "Clone", "Void", "Little Prince"),
    4 to listOf("Hog Rider", "Valkyrie", "Musketeer", "Mini PEKKA", "Baby Dragon", "Dark Prince",
        "Fireball", "Poison", "Freeze", "Furnace", "Mortar", "Tesla", "Inferno Dragon", "Zappies",
        "Lumberjack", "Night Witch", "Battle Healer", "Hunter", "Flying Machine", "Goblin Drill",
        "Skel Dragons", "Golden Knight", "Skeleton King", "Mighty Miner", "Phoenix", "Goblin Cage"),
    5 to listOf("Giant", "Wizard", "Prince", "Balloon", "Witch", "Bowler", "Executioner",
        "Cannon Cart", "Graveyard", "Electro Dragon", "Royal Hogs", "Rascals", "Archer Queen",
        "Monk", "Goblinstein"),
    6 to listOf("Rocket", "Lightning", "X-Bow", "Royal Giant", "Giant Skel", "Sparky",
        "Elite Barbs", "Elixir Collector", "Goblin Giant", "Spirit Empress", "Boss Bandit"),
    7 to listOf("PEKKA", "Mega Knight", "Lava Hound", "Electro Giant", "Barb Hut", "Royal Recruits"),
    8 to listOf("Golem"),
    9 to listOf("Three Musk")
)

class ElixirBar(c: Context) : View(c) {
    var value = 5f
        set(v) { field = v; invalidate() }
    private val bg = Paint().apply { color = 0xFF333344.toInt() }
    private val fg = Paint().apply { color = 0xFFE056FD.toInt() }
    private val tick = Paint().apply { color = 0xFF1B1B2F.toInt(); strokeWidth = 2f }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cv.drawRect(0f, 0f, w, h, bg)
        cv.drawRect(0f, 0f, w * value / 10f, h, fg)
        for (i in 1..9) cv.drawLine(w * i / 10f, 0f, w * i / 10f, h, tick)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var elixirTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var bar: ElixirBar
    private lateinit var infoTv: TextView
    private lateinit var chips: LinearLayout
    private lateinit var chipsScroll: HorizontalScrollView
    private val h = Handler(Looper.getMainLooper())

    private var startMs = 0L
    private var lastMs = 0L
    private var elixir = 5f
    private var mult = 1
    private val order = ArrayList<String>()
    private val hideChips = Runnable { chipsScroll.visibility = View.GONE }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if (startMs != 0L) {
                val t = (now - startMs) / 1000f
                mult = if (t < 120f) 1 else if (t < 240f) 2 else 3
                elixir = minOf(10f, elixir + (now - lastMs) / 1000f * mult / 2.8f)
            }
            lastMs = now
            render(now)
            h.postDelayed(this, 50)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildUi()
        h.post(ticker)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cr", "CR Tracker", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cr")
            .setContentTitle("CR Tracker radi")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = r.toFloat()
    }

    private fun tv(text: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    }

    private fun btn(text: String, size: Float = 16f, onClick: () -> Unit): TextView = tv(text, size).apply {
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = rounded(0xFF3A3A5C.toInt(), dp(8))
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        lp = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
            background = rounded(0xE61B1B2F.toInt(), dp(14))
        }

        // Header (vuci za pomicanje panela)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        elixirTv = tv("5.0", 30f, 0xFFE056FD.toInt()).apply {
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            minWidth = dp(70)
        }
        timeTv = tv("", 12f, 0xFFCCCCDD.toInt())
        header.addView(elixirTv)
        header.addView(timeTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(btn("▶") { newMatch() })
        header.addView(btn("—") {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }.also { (it.layoutParams as? LinearLayout.LayoutParams) })
        header.addView(btn("✕") { stopSelf() })

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }

        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        bar = ElixirBar(this)
        body.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(10))
            .apply { topMargin = dp(4); bottomMargin = dp(6) })

        // Cijene 1-9
        val costRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in 1..9) {
            val b = tv(c.toString(), 18f).apply {
                background = rounded(0xFF3A3A5C.toInt(), dp(8))
                setOnClickListener { spend(c) }
            }
            costRow.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        body.addView(costRow)

        // Izbor karte (opcionalno, nestaje nakon 3.5 s)
        chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipsScroll = HorizontalScrollView(this).apply {
            visibility = View.GONE
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }
        body.addView(chipsScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        // Ispravci
        val corr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(2), dp(6), dp(2), 0) }
        corr.addView(btn("−1", 14f) { elixir = maxOf(0f, elixir - 1) }, m)
        corr.addView(btn("+1", 14f) { elixir = minOf(10f, elixir + 1) }, m)
        corr.addView(btn("Očisti špil", 12f) { order.clear(); updateInfo() }, m)
        body.addView(corr)

        infoTv = tv("", 11f, 0xFFCCCCDD.toInt()).apply { gravity = Gravity.START }
        body.addView(infoTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        root.addView(header)
        root.addView(body)
        wm.addView(root, lp)
        updateInfo()
    }

    private fun newMatch() {
        startMs = SystemClock.elapsedRealtime()
        lastMs = startMs
        elixir = 5f
        mult = 1
        order.clear()
        updateInfo()
    }

    private fun spend(c: Int) {
        elixir = maxOf(0f, elixir - c)
        chips.removeAllViews()
        for (name in CARDS[c].orEmpty()) {
            chips.addView(btn(name, 12f) {
                record(name)
                chipsScroll.visibility = View.GONE
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(4) })
        }
        chipsScroll.scrollTo(0, 0)
        chipsScroll.visibility = View.VISIBLE
        h.removeCallbacks(hideChips)
        h.postDelayed(hideChips, 3500)
    }

    private fun record(name: String) {
        order.remove(name)
        order.add(name)
        if (order.size > 8) order.removeAt(0)
        updateInfo()
    }

    private fun updateInfo() {
        infoTv.text = if (order.size == 8)
            "Ruka (~): ${order.take(4).joinToString(", ")}\nSljedeća u ruku: ${order[4]}"
        else
            "Viđeno ${order.size}/8: ${order.joinToString(", ")}"
    }

    private fun render(now: Long) {
        elixirTv.text = String.format("%.1f", elixir)
        elixirTv.setTextColor(
            when {
                elixir <= 3f -> 0xFF2ECC71.toInt()   // zeleno: napadni
                elixir >= 9f -> 0xFFFF7675.toInt()   // pun elixir
                else -> 0xFFE056FD.toInt()
            }
        )
        bar.value = elixir
        timeTv.text = if (startMs == 0L) "pritisni ▶ na startu" else {
            val t = ((now - startMs) / 1000).toInt()
            String.format("%d:%02d  %dx", t / 60, t % 60, mult)
        }
    }
}
